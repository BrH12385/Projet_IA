import joblib
import numpy as np

def get_float_input(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("❌ Entrée invalide. Veuillez entrer un nombre.")

def get_int_input(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("❌ Entrée invalide. Veuillez entrer un entier.")

def predict_vessel_type():
    print("🔍 Chargement du modèle et du scaler...")
    model = joblib.load("model.pkl")
    scaler = joblib.load("scaler.pkl")

    print("\n Entrez les caractéristiques du navire :")

    # Seules les variables sélectionnées par corrélation sont demandées
    Cargo = get_int_input("Cargo : ")
    Draft = get_float_input("Draft : ")
    Width = get_float_input("Width : ")
    Length = get_float_input("Length : ")
    

    # Organiser l'entrée dans l'ordre des colonnes d'entraînement
    input_data = np.array([[Cargo, Draft, Width, Length,]])

    # Normalisation
    input_scaled = scaler.transform(input_data)

    # Prédiction
    prediction = model.predict(input_scaled)

    print(f"\n✅ Type de navire prédit (VesselType) : {prediction[0]}")

if __name__ == "__main__":
    predict_vessel_type()




