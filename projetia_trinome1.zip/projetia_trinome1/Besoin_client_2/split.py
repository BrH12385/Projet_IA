# 1. Import des bibliothèques nécessaires
import pandas as pd
from sklearn.model_selection import train_test_split

# 2. Chargement des données préparées
X = pd.read_csv("X_prepared.csv")
y = pd.read_csv("y_prepared.csv")['VesselType']  # s'assurer qu'on extrait bien la colonne cible

# 3. Vérification des données
print("Aperçu des données X :")
print(X.head())
print("\nAperçu de la cible y :")
print(y.head())
print(f"\nDimensions de X : {X.shape}")
print(f"Dimensions de y : {y.shape}")

# 4. Découpage en ensembles d'entraînement et de test (80/20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 5. Affichage des dimensions
print("\nDécoupage terminé :")
print(f"X_train : {X_train.shape}")
print(f"X_test  : {X_test.shape}")
print(f"y_train : {y_train.shape}")
print(f"y_test  : {y_test.shape}")

# 6. Sauvegarde des ensembles
X_train.to_csv("X_train.csv", index=False)
X_test.to_csv("X_test.csv", index=False)
y_train.to_csv("y_train.csv", index=False)
y_test.to_csv("y_test.csv", index=False)

print("\n✅ Fichiers enregistrés : X_train.csv, X_test.csv, y_train.csv, y_test.csv")
