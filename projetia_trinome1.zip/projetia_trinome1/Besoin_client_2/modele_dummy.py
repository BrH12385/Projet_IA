import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import joblib

# 1. Chargement
X_train = pd.read_csv("X_train.csv")
X_test = pd.read_csv("X_test.csv")
y_train = pd.read_csv("y_train.csv")["VesselType"]
y_test = pd.read_csv("y_test.csv")["VesselType"]

# 2. Normalisation
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 3. DummyClassifier (stratégie : "most_frequent")
model = DummyClassifier(strategy="most_frequent")
model.fit(X_train_scaled, y_train)

# 4. Prédiction et évaluation
y_pred = model.predict(X_test_scaled)

print("📊 Rapport de classification – DummyClassifier :")
print(classification_report(y_test, y_pred))

# 5. Matrice de confusion
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Reds")
plt.title("Matrice de confusion – DummyClassifier")
plt.xlabel("Prédit")
plt.ylabel("Réel")
plt.savefig("matrice_confusion_dummy.png")
plt.close()

# 6. Sauvegarde
joblib.dump(model, "model_dummy.pkl")
joblib.dump(scaler, "scaler_dummy.pkl")
print("✅ Dummy model sauvegardé dans model_dummy.pkl")
