# 1. Import des bibliothèques
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# 2. Chargement des fichiers d'entraînement et de test
X_train = pd.read_csv("X_train.csv")
X_test = pd.read_csv("X_test.csv")
y_train = pd.read_csv("y_train.csv")["VesselType"]
y_test = pd.read_csv("y_test.csv")["VesselType"]

# 3. Normalisation (important pour certains modèles)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 4. Création et entraînement du modèle Random Forest
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# 5. Prédictions
y_pred = model.predict(X_test_scaled)

# 6. Évaluation du modèle
print("📊 Rapport de classification :")
print(classification_report(y_test, y_pred))

# Matrice de confusion (affichée et sauvegardée)
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.title("Matrice de confusion - Random Forest")
plt.xlabel("Prédit")
plt.ylabel("Réel")
plt.savefig("matrice_confusion.png")
plt.close()

# 7. Sauvegarde du modèle et du scaler pour la prédiction future
joblib.dump(model, "model.pkl")
joblib.dump(scaler, "scaler.pkl")

print("✅ Modèle sauvegardé dans model.pkl")
print("✅ Scaler sauvegardé dans scaler.pkl")
print("📁 Matrice de confusion enregistrée dans matrice_confusion.png")

